(function($) {
	$(document).ready(function() {
		$('.save_this_search').click(function() {
			  $("#edit-submitsave").click();
		});		
    });
})(jQuery);
