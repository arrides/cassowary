(function ($) {
  $(function() {
    $('.view-user-portfolio-company-2 .views-field-field-logo a.active').parents('li').addClass('active');
  });
})(jQuery);