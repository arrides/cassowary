<div class="applied-job">
 <?php foreach ($vars['strings'] as $string): ?>
   <p><?php print $string; ?></p>
 <?php endforeach;?>
</div>
